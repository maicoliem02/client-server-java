package thicuoiki;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class client {
    public static void main(String[] args) {
        DatagramSocket socket = null;
        Scanner scanner = new Scanner(System.in);

        try {
            socket = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName("localhost");

            while (true) {
                System.out.print("Enter an integer (enter 0 to finish): ");
                int number = scanner.nextInt();
                String sendData = String.valueOf(number);
                byte[] sendDataBytes = sendData.getBytes();

                DatagramPacket sendPacket = new DatagramPacket(sendDataBytes, sendDataBytes.length, serverAddress, 9876);
                socket.send(sendPacket);

                if (number == 0) {
                    break;
                }
            }

            // Nhận kết quả từ máy chủ
            byte[] receiveResultData = new byte[1024];
            DatagramPacket receiveResultPacket = new DatagramPacket(receiveResultData, receiveResultData.length);
            socket.receive(receiveResultPacket);

            String resultFromServer = new String(receiveResultPacket.getData(), 0, receiveResultPacket.getLength());
            System.out.println("Result from server: " + resultFromServer);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }
}

