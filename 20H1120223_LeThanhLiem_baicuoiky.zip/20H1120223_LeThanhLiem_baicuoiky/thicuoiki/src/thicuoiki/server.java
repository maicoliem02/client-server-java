package thicuoiki;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.HashSet;

public class server {
    public static void main(String[] args) {
        DatagramSocket socket = null;
        HashSet<Integer> numberSet = new HashSet<>();

        try {
            socket = new DatagramSocket(9876);
            byte[] receiveData = new byte[1024];

            DatagramPacket receivePacket;  // Khai báo biến receivePacket ở đây

            while (true) {
                receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);

                String receivedData = new String(receivePacket.getData(), 0, receivePacket.getLength());
                int number = Integer.parseInt(receivedData);

                if (number == 0) {
                    break;
                }

                if (!numberSet.contains(number)) {
                    numberSet.add(number);
                }
            }

            int sum = numberSet.stream().mapToInt(Integer::intValue).sum();
            String result = String.valueOf(sum);

            // Gửi kết quả về client
            byte[] sendResultData = result.getBytes();
            DatagramPacket sendResultPacket = new DatagramPacket(sendResultData, sendResultData.length,
                    receivePacket.getAddress(), receivePacket.getPort());
            socket.send(sendResultPacket);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }
}



